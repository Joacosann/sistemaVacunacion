package centroVacunacion;

public class Sinopharm extends Vacuna {

	Sinopharm(String edad, int temperatura) {
		super(edad, temperatura);
		
	}

}
