package centroVacunacion;

public class Astrazeneca extends Vacuna {

	Astrazeneca(String edad, int temperatura) {
		super(edad, temperatura);
		
	}

}
