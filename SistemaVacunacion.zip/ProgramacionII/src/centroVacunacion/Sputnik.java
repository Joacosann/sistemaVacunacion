package centroVacunacion;

public class Sputnik extends Vacuna {

	Sputnik(String edad, int temperatura) {
		super(edad, temperatura);
		
	}

}
